#### Installasjon av Windows Snipping Tool ####

1. Høyre-klikk på Run og velg "Kjør som/Run as administrator"

Snipping Tool skal nå være installert og ligge i start-menyen. Denne mappen kan slettes.
