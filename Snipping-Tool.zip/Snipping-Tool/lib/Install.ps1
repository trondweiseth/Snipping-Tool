﻿Copy-Item .\SnippingTool.exe C:\Windows\System32
$en = Test-Path C:\Windows\System32\en-US
$nb = Test-Path C:\Windows\System32\nb-NO
if ($en = $true) {Copy-Item .\snippingtool-EN-mui\SnippingTool.exe.mui C:\Windows\System32\en-US}
if ($nb = $true) {Copy-Item .\snippingtool-NO-mui\SnippingTool.exe.mui C:\Windows\System32\nb-NO}

# Define the paths and names of the shortcut and executable files
$shortcutName = "Snipping Tool.lnk"
$shortcutPath = "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Accessories"
$exePath = "C:\Windows\System32\SnippingTool.exe"

# Create a WshShell COM object
$wshShell = New-Object -ComObject WScript.Shell

# Create the shortcut object
$shortcut = $wshShell.CreateShortcut("$shortcutPath\$shortcutName")

# Set the properties of the shortcut
$shortcut.TargetPath = $exePath
$shortcut.WorkingDirectory = Split-Path $exePath
$shortcut.IconLocation = "$exePath,0"
$shortcut.Save()

# Clean up the COM object
[System.Runtime.Interopservices.Marshal]::ReleaseComObject($wshShell) | Out-Null